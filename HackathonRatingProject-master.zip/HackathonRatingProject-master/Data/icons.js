const icons = [
    {
        photo: url="https://cdn.icon-icons.com/icons2/901/PNG/128/vkontakte_icon-icons.com_69251.png"
    },
    {
        photo: url="https://cdn.icon-icons.com/icons2/1211/PNG/128/1491580635-yumminkysocialmedia26_83102.png"
    },
    {
        photo: url="https://cdn.icon-icons.com/icons2/1211/PNG/128/1491579542-yumminkysocialmedia22_83078.png"
    },
    {
        photo: url="https://cdn.icon-icons.com/icons2/1211/PNG/128/1491579586-yumminkysocialmedia21_83091.png"
    },
    {
        photo: url="https://cdn.icon-icons.com/icons2/1211/PNG/128/1491580651-yumminkysocialmedia28_83061.png"
    }
];

    module.exports = {
        icons
    };