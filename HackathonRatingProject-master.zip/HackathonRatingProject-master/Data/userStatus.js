let userStatus = [ { userStatus: false } ];

module.exports = {
    userStatus
};