let usersInfo = [];

module.exports = {
    usersInfo
};