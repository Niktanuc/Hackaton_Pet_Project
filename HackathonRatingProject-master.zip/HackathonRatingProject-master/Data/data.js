const data = [
    {
        name: "User_Number1",
        altname: "Nature",
        photo: "https://ksassets.timeincuk.net/wp/uploads/sites/46/2017/03/Priti-Patel-re-sized.jpg",
        src: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/nature-quotes-1557340276.jpg?crop=0.666xw:1.00xh;0.168xw,0&resize=640:*",
        alt: "Nature",
        description: "Hello, this is my description!",
        id: "1",
        likes: 0
    },
    {
        name: "User_Number2",
        altname: "Photo",
        photo: "https://www.loyatic.eu/wp-content/uploads/2017/11/iStock_000020004182Medium1.jpg",
        src: "https://wwwimage-secure.cbsstatic.com/thumbnails/photos/w1920/marquee/1025957/72e1f4c7b764c8d2_mwp_hp_hero_landscape.jpg",
        alt: "Photo",
        description: "Hello, this is my description!",
        id: "2",
        likes: 0
    },
    {
        name: "User_Number3",
        altname: "BEST",
        photo: "https://cdn.jetphotos.com/full/5/53285_1432288602.jpg",
        src: "https://cdn.jetphotos.com/full/5/53285_1432288602.jpg",
        alt: "BEST",
        description: "Hello, this is my description!",
        id: "3",
        likes: 0
    },
    {
        name: "User_Number4",
        altname: "eggs",
        photo: "https://www.washingtonpost.com/resizer/1RhnmRzobv_b5lzu2YIz381sV8s=/1484x0/arc-anglerfish-washpost-prod-washpost.s3.amazonaws.com/public/4ZLH33AYAAI6TOHGKZYZBQX5BA.jpg",
        src: "https://hips.hearstapps.com/delish/assets/18/08/1519321899-hard-boiled-eggs-horizontal.jpg",
        alt: "eggs",
        description: "Hello, this is my description!",
        id: "4",
        likes: 0
    },
    {
        name: "User_Number5",
        altname: "Lake",
        photo: "https://cdn.lifehack.org/wp-content/uploads/2015/01/alpha-woman-1024x768.jpeg",
        src: "https://nighthelper.com/wp-content/uploads/2016/03/nature_waterfall_summer_lake_trees_90400_3840x2160.jpg",
        alt: "Lake",
        description: "Hello, this is my description!",
        id: "5",
        likes: 0
    },
    {
        name: "User_Number6",
        altname: "Smoothie",
        photo: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/delish-how-to-make-a-smoothie-horizontal-1542310071.png?crop=0.803xw:0.923xh;0.116xw,0.00510xh&resize=480:*",
        src: "https://www.culinaryhill.com/wp-content/uploads/2015/01/Caribbean-Passion-Smoothie-Jamba-Juice-Copycat-Culinary-Hill-square.jpg",
        alt: "Smoothie",
        description: "Hello, this is my description!",
        id: "6",
        likes: 0
    }
];

module.exports = {
    data
};