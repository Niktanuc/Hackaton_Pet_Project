import React from 'react';

const ErrorMessage = () => {
    return (
        <img src="https://cdn.wallpapersafari.com/34/82/YRzXPk.jpeg" alt="error" />
    );
};

export default ErrorMessage;